import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:maps_launcher/maps_launcher.dart';

class Lokasi extends StatefulWidget {
  const Lokasi({super.key});

  @override
  State<Lokasi> createState() => _LokasiState();
}

class _LokasiState extends State<Lokasi> {
  int _counter = 0;
  String address = "";

  Position _myPosition = Position(
      longitude: 0,
      latitude: 0,
      timestamp: DateTime.now(),
      accuracy: 0,
      altitude: 0,
      heading: 0,
      speed: 0,
      speedAccuracy: 0);

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  setAddress() async {
    List<Placemark> placemarks = await placemarkFromCoordinates(
        this._myPosition.latitude, this._myPosition.longitude);
    Placemark placemark = placemarks[0];
    setState(() {
      address = placemark.country.toString() +
          "," +
          placemark.administrativeArea.toString() +
          "," +
          placemark.locality.toString() +
          "," +
          placemark.street.toString() +
          "," +
          placemark.name.toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Koordinat Point",
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
            Text(
              "$_myPosition",
              style: TextStyle(fontSize: 12),
            ),
            SizedBox(
              height: 20,
            ),
            Text(
              "Address",
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
            Text(address),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FloatingActionButton(
                  onPressed: () {
                    _determinePosition();
                    setAddress();
                  },
                  tooltip: 'Increment',
                  child: Icon(Icons.location_on),
                ),
                SizedBox(width: 20,),
                FloatingActionButton(
                  onPressed: () {
                    MapsLauncher.launchCoordinates(
                        this._myPosition.latitude, this._myPosition.longitude);
                  },
                  child: Text("maps"),
                )
              ],
            )
          ],
        ),
      ),
    );
  }

  Future<void> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled don't continue
      // accessing the position and request users of the
      // App to enable the location services.
      // return Future.error('Location services are disabled.');
      print("fail");
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        // Permissions are denied, next time you could try
        // requesting permissions again (this is also where
        // Android's shouldShowRequestPermissionRationale
        // returned true. According to Android guidelines
        // your App should show an explanatory UI now.
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }

    Position myPosition = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best);
    setState(() {
      _myPosition = myPosition;
    });
  }
}
